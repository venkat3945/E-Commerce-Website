<?php
session_start();

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "venkatkiran";
$connect = mysqli_connect($hostname, $username, $password, $dbname);

$name = $_POST['username'];
$password = $_POST['password'];

$s = "select * from usertable where name = '$name' && password='$password'";
$result = mysqli_query($connect, $s);
$num = mysqli_num_rows($result);
if($num == 1){
    header('location:first.php');
}else{
    header('location:login.php');
}
?>