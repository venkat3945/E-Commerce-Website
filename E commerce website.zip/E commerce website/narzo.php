<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
                width: 100%;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .dropbtn{
                font-size: 20px;
                background-color: blueviolet;
                color: white;
                margin: 0;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                overflow: hidden;
                text-align: left;
            }
            .dropdown-content a:hover{
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
            .realmenarzo305gspecs{
                margin-left: 450px;
                overflow: hidden;
                margin-top: 50px;
            }
            .realmenarzo30pro5gspecs{
                margin-left: 450px;
                overflow: hidden;
                margin-top: 50px;
            }
            .realmenarzo50aspecs{
                margin-left: 450px;
                overflow: hidden;
                margin-top: 50px;
            }
        </style>
    </head>
    <body>
        <div class="navbar sticky-top">
            <a style="margin-left: 275px; margin-top: 8px;">Flipkart</a>
            <a><input type="search" name="search" placeholder="search" style="width: 350px; margin-left: 50px; margin-top: 8px;"></a>
            <div class="dropdown">
                <p class="dropbtn" style="margin-left: 75px; margin-top: 8px; cursor: pointer;">More</p>
                <div class="dropdown-content">
                    <a>Notification Preferences</a>
                    <a>Sell On Flipkart</a>
                    <a>24x7 Customer Care</a>
                    <a>Advertise</a>
                    <a>Download App</a>
                </div>
            </div>
            <a style="margin-left: 100px; margin-top: 8px;">Cart</a>
        </div>
        <div class="reamlenarzo305g">
            <img src="./Screenshot 2022-03-25 214349.png" style="margin-left: 200px;  float: left;">
            <div class="realmenarzo305gspecs">
                <h3>Realme Narzo 30 5G (Racing Blue, 128 GB)</h3>
                <ul>
                    <li>6 GB RAM | 128 GB ROM | Expandable Upto 1TB</li>
                    <li>16.51 cm (6.5 inch) Full HD+ Display</li>
                    <li>48MP + 2MP + 2MP | 16MP Front Camera</li>
                    <li>5000 mAh Battery</li>
                    <li>MediaTek Dimensity 700 Processor</li>
                    <li>1 Year Warranty</li>
                    <li>Price 16,999</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <hr>
        <div class="realmenarzo30pro5g">
            <img src="./Screenshot 2022-03-25 214424.png" style="float: left; margin-left: 200px;">
            <div class="realmenarzo30pro5gspecs">
                <h3>Realme Narzo 30 Pro 5G(Blade Silver, 128 GB)</h3>
                <ul>
                    <li>8 GB RAM | 128 GB ROM | Expandable Upto 256 GB</li>
                    <li>16.51 cm (6.5inch) Full HD+ Display</li>
                    <li>48MP + 8MP + 2MP | 16MP  Front Camera  </li>
                    <li>5000 mAh Battery</li>
                    <li>MediaTek Dimensity 800U Processor</li>
                    <li>1 Year Warranty</li>
                    <li>Price 19,999</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <hr>    
        <div class="realmenarzo50a">
            <img src="./Screenshot 2022-03-25 214506.png" style="float: left; margin-left: 200px;"> 
            <div class="realmenarzo50aspecs">
                <h3>Realme Narzo 50A (Oxygen Green, 64 GB)</h3>
                <ul>
                    <li>4 GB RAM | 64 GB ROM | Exapndable Upto 256 GB</li>
                    <li>50MP + 2MP + 2MP | 8MP Front Camera</li>
                    <li>6000 mAh Battery</li>
                    <li>MediaTek Helio G85 Processor</li>
                    <li>1 Year Warranty</li>
                    <li>Price 11,999</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
    </body>
</html>