<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
                width: 100%;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .dropbtn{
                font-size: 20px;
                background-color: blueviolet;
                color: white;
                margin: 0;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                overflow: hidden;
                text-align: left;
            }
            .dropdown-content a:hover{
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }.hpenvyspecs{
                margin-left: 500px;
                overflow: hidden;
            }.hpenvy1specs{
                margin-left: 500px;
                overflow: hidden;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <a style="margin-left: 275px; margin-top: 8px;">Flipkart</a>
            <a><input type="search" name="search" placeholder="search" style="width: 350px; margin-left: 50px; margin-top: 8px;"></a>
            <div class="dropdown">
                <p class="dropbtn" style="margin-left: 75px; margin-top: 8px; cursor: pointer;">More</p>
                <div class="dropdown-content">
                    <a>Notification Preferences</a>
                    <a>Sell On Flipkart</a>
                    <a>24x7 Customer Care</a>
                    <a>Advertise</a>
                    <a>Download App</a>
                </div>
            </div>
            <a style="margin-left: 100px; margin-top: 8px;">Cart</a>
        </div>
        <br>
        <br>
        <div class="hpenvy">
            <img src="./Screenshot 2022-03-26 173506.png" style="float: left; overflow: hidden; margin-left: 50px;">
            <div class="hpenvyspecs">
                <h3>HP Envy 13 x 360</h3>
                <br>
                <br>
                <ul>
                    <li>16 GB RAM | 512 GB SSD</li>
                    <li>Windows 11 Operating System</li>
                    <li>Screen Size is 13 Inch</li>
                    <li>BackLit Keyboard</li>
                    <li>TouchScreen Display</li>
                    <li>DDR4 RAM</li>
                    <li>Intel Core i7 Processor (11th Gen)</li>
                    <li>Price 1,03,140</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <hr>
        <br>
        <br>
        <div class="hpenvy1">
            <img src="./Screenshot 2022-03-26 175451.png" style="float: left; overflow: hidden; margin-left: 50px;">
            <div class="hpenvy1specs">
                <h3>Hp Envy 15</h3>
                <ul>
                    <li>Intel Core i7 Processor</li>
                    <li>16 GB RAM | 1 TB SSD</li>
                    <li>64-Bit Operating System</li>
                    <li>39.62 cm (15.62 inch) Display</li>
                    <li>Microsodt Office Home and Student 2021</li>
                    <li>1 Year Onsite Warranty</li>
                    <li>4 GB Graphics</li>
                    <li>Price 1,25,999</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
    </body>
</html>