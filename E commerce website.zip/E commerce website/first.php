<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .drop-btn{
                font-size: 20px;
                border: none;
                color: white;
                margin: 0;
                background-color: blueviolet;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                text-align: left;
            }
            .dropdown-content a:hover {
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
            .items{
                display: block;
                
            }
            .slidefade{
                width: 100%;
                height: 100px;
            }
            .container{
                position: relative;
                width: 100%;
                margin: auto;
            }
            .previousround{
                position: absolute;
                top: 50%;
                padding: 15px;
                color: black;
                cursor: pointer;
                float: left;
                overflow: hidden;
                
            }
            .nextround{
                position: absolute;
                top: 50%;
                padding: 15px;
                color: black;
                cursor: pointer;
                float: right;
                overflow: hidden;
                    
            }
            .nextround{
                right: 0;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <a style="margin-left: 150px; padding: 8px;">Flipkart</a>
            <a style="margin-left: 150px; padding: 8px;"><input type="search" placeholder="search"></a>
            <a style="margin-left: 150px; padding: 8px;"><button style="background-color: blueviolet; color: white; border: none; cursor: pointer;" onclick="myfunction()">Login</button></a>
            <div class="dropdown">
                <button class="drop-btn" style="margin-left: 150px; padding: 8px;">More</button>
                <div class="dropdown-content">
                    <a style="cursor: pointer;">Notification Preferences</a>
                    <a style="cursor: pointer;">Sell on Flipkart</a>
                    <a style="cursor: pointer;">24x7 Customer Care</a>
                    <a style="cursor: pointer;">Advertise</a>
                    <a style="cursor: pointer;">Download App</a>
                </div>
            </div>
            <a style="margin-left: 150px; padding: 8px;">Cart</a>
        </div>

        <div class="items">
            <img src="./Screenshot 2022-03-23 133827.png" style="padding-right:70px; padding-left: 25px; cursor: pointer;">
            <img src="./Screenshot 2022-03-23 133851.png" style="padding-right:70px; cursor: pointer;">
            <a href="mobiles.php"><img src="./Screenshot 2022-03-23 133911.png" style="padding-right:70px; cursor: pointer;" onclick="performclick"></a>
            <img src="./Screenshot 2022-03-23 150848.png" style="padding-right:70px; cursor: pointer;"> 
            <a href="laptops.php"><img src="./Screenshot 2022-03-23 150907.png" style="padding-right:70px; cursor: pointer;" onclick="performclick"></a>
            <img src="./Screenshot 2022-03-23 150927.png" style="padding-right:70px; cursor: pointer;">
            <img src="./Screenshot 2022-03-23 150944.png" style="padding-right:70px; cursor: pointer;">
        </div>
        <h2 style="text-align:center; margin-top:10px;">TRENDING LAUNCHES</h2><br>
        <br>
        <div class="container fade">
            <div class="slide fade"><img src="./Screenshot 2022-03-23 153452.png" style="width: 100%;"></div>
            <div class="slide fade"><img src="./Screenshot 2022-03-23 153526.png" style="width: 100%;"></div>
            <div class="slide fade"><img src="./Screenshot 2022-03-23 153651.png" style="width: 100%;"></div>            
            <div class="slide fade"><img src="./Screenshot 2022-03-23 153721.png" style="width: 100%;"></div>
            
            <a href="#" class="previousround" onclick="nextslide(-1)">&#8249;</a>
            <a href="#" class="nextround" onclick="nextslide(1)">&#8250;</a>
            </div>
        <script>
            function myfunction(){
                let userid = prompt("Enter your USERID ", "");
                let password = prompt("Enter your password", ""); 
            }
            var index = 1;
           function nextslide(n) {
               displayslides(index = index+n);
           }
           displayslides(index);

           function displayslides(n) {
               var i;
               var slides=document.getElementsByClassName("slide");
               if (n > slides.length) {index = 1}
               if (n < 1) {index = slides.length}
               for (i=0; i < slides.length; i++) {
                   slides[i].style.display = "none";
               }
               slides[index - 1].style.display = "block";
           }
        </script>
    </body>
</html>