<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "venkatkiran";
$connect = mysqli_connect($hostname, $username, $password, $dbname);
if($connect){
    echo "Connection success";
}else {
    echo "Connection unsuccess";
}
$tb = "CREATE TABLE project1 (name VARCHAR(50), mobile VARCHAR(10), address VARCHAR(50), housenumber VARCHAR(20), landmark VARCHAR(20))";
$q = mysqli_query($connect, $tb);
if($q){
    echo "table created";
}else{
    echo "table not created";
}
?>