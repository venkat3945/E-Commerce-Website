<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
    </style>
</head>
<body>
    <img src="./download (9).jpg" style="margin-left:40%; margin-top:2%;">
    <h2>Thank You For ordering</h2><br>
    <br>
    <h2>Your Order Has Been placed</h2><br>
    <br>
    <h2>Your Address data has been sent to our delivery courier partner</h2><br>
    <br>
    <h2>Your Order will be delivered in 2 days</h2><br>
    <br>

</body>
</html>