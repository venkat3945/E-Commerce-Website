<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
                width: 100%;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .dropbtn{
                font-size: 20px;
                background-color: blueviolet;
                color: white;
                margin: 0;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                overflow: hidden;
                text-align: left;
            }
            .dropdown-content a:hover{
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
        </style>

    </head>
    <body>
        <div class="navbar">
            <a style="margin-left: 275px; margin-top: 8px;">Flipkart</a>
            <a><input type="search" name="search" placeholder="search" style="width: 350px; margin-left: 50px; margin-top: 8px;"></a>
            <div class="dropdown">
                <p class="dropbtn" style="margin-left: 75px; margin-top: 8px; cursor: pointer;">More</p>
                <div class="dropdown-content">
                    <a>Notification Preferences</a>
                    <a>Sell On Flipkart</a>
                    <a>24x7 Customer Care</a>
                    <a>Advertise</a>
                    <a>Download App</a>
                </div>
            </div>
            <a style="margin-left: 100px; margin-top: 8px;">Cart</a>
        </div>
        <h2 style="font-size: 25px; text-align: center; margin-top: 25px;">Select Your Favourite Brand To Shop</h2><br>
        <br>
        <br>
        <a href="realmemobiles.php"><img src="./Screenshot 2022-03-24 143001.png" style="margin-left: 50px; cursor: pointer;" onclick="performclick"></a>
        <a href="narzo.php"><img src="./Screenshot 2022-03-24 143603.png" style="margin-left: 50px; cursor: pointer;" onclick="performclick"></a>
        <a href="mimobiles.php"><img src="./Screenshot 2022-03-24 143624.png" style="margin-left: 50px; cursor:pointer;" onclick="performclick"></a>
        <img src="./Screenshot 2022-03-24 143645.png" style="margin-left: 50px;">
        <img src="./Screenshot 2022-03-24 143702.png" style="margin-left: 50px;">
        <img src="./Screenshot 2022-03-24 143541.png" style="margin-left: 50px;"><br>
        <br>
        <br>
        <img src="./OnePlus-Logo.wine1.png" style="height: 140px; width: 140px; border: solid grey; border-radius: 18px; margin-left: 50px;">
        <img src="./vivo-1-logo-png-transparent.png" style="height: 140px; width: 140px; border: solid grey; border-radius: 18px; margin-left: 50px;">
        <img src="./iQOO-Logo.jpg" style="height: 140px; width: 140px; border: solid grey; border-radius: 18px; margin-left: 50px;"> 
    </body>
    <script>
    </script>
</html>