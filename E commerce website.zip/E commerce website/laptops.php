<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
                width: 100%;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .dropbtn{
                font-size: 20px;
                background-color: blueviolet;
                color: white;
                margin: 0;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                overflow: hidden;
                text-align: left;
            }
            .dropdown-content a:hover{
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <a style="margin-left: 275px; margin-top: 8px;">Flipkart</a>
            <a><input type="search" name="search" placeholder="search" style="width: 350px; margin-left: 50px; margin-top: 8px;"></a>
            <div class="dropdown">
                <p class="dropbtn" style="margin-left: 75px; margin-top: 8px; cursor: pointer;">More</p>
                <div class="dropdown-content">
                    <a>Notification Preferences</a>
                    <a>Sell On Flipkart</a>
                    <a>24x7 Customer Care</a>
                    <a>Advertise</a>
                    <a>Download App</a>
                </div>
            </div>
            <a style="margin-left: 100px; margin-top: 8px;">Cart</a>
        </div>
        <br>
        <br>
        <h2 style="text-align: center;">Select Your Favourite Brand To Shop</h2>
        <br>
        <br>
        <br>
        <a href="hplaptops.php"><img src="./HP_Logo.5e42b7e88a7fe.jpg" style="height: 100px; width: 100px; border: solid grey; border-radius: 12px; margin-left: 80px; cursor: pointer;" onclick="performclick"></a>
        <a href="delllaptops.php"><img src="./R.jpg" style="height: 100px; width: 100px; border: solid grey; border-radius: 12px; margin-left: 100px; cursor: pointer;" onclick="performclick"></a>
    </body>
</html>