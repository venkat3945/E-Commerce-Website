<?php
if(isset($_POST['name'])){
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "venkatkiran";
    $connect = mysqli_connect($hostname, $username, $password, $dbname);
    if($connect){
        echo "Connection success";
    }else{
        echo "Connection unsuccess";
    }
}
$name = $_POST['name'];
$mobile = $_POST['phno'];
$address = $_POST['address'];
$housenumber = $_POST['hno'];
$landmark = $_POST['landmark'];

$sq = "INSERT INTO project1(name, mobile, address, housenumber, landmark)
VALUES ('$name', '$mobile', '$address', '$housenumber', '$landmark')";
$q = mysqli_query($connect, $sq);
if($q){
    echo "data sent";
}else{
    echo "data not sent";
}
?>