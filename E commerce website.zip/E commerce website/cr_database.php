<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "";
$connect = mysqli_connect($hostname, $username, $password);
if($connect){
    echo "Connection success";
}else{
    echo "connection failed";
}
$db = "CREATE DATABASE venkatkiran";
$q = mysqli_query($connect, $db);
if($q){
    echo "Database created";
}else{
    echo "Database not created";
}
?>