<?php
session_start();
header ('location:login.php');
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "venkatkiran";
$connect = mysqli_connect($hostname, $username, $password, $dbname);

$name = $_POST['username'];
$password = $_POST['password'];

$s = "select * from usertable where name = '$name'";
$result = mysqli_query($connect, $s);
$num = mysqli_num_rows($result);
if($num == 1){
    echo "username already taken";
}else{
    $reg = "INSERT INTO usertable(name, password) 
    VALUES ('$name', '$password')";
    mysqli_query($connect, $reg);
    echo "Registration successful";
}
?>