<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0;
            }
            .navbar{
                overflow: hidden;
                background-color: blueviolet;
                height: 40px;
                width: 100%;
            }
            .navbar a{
                float: left;
                font-size: 20px;
                color: white;
                text-align: center;
                text-decoration: none;
            }
            .dropdown{
                float: left;
                overflow: hidden;
            }
            .dropbtn{
                font-size: 20px;
                background-color: blueviolet;
                color: white;
                margin: 0;
            }
            .dropdown-content{
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
            }
            .dropdown-content a{
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                overflow: hidden;
                text-align: left;
            }
            .dropdown-content a:hover{
                background-color: #ddd;
            }
            .dropdown:hover .dropdown-content {
                display: block;
            }
            .mi5gspecs{
                margin-left: 450px;
                overflow: hidden;
                margin-top: 50px;
            }
            .mi11tpro5gspecs{
                margin-left: 450px;
                overflow: hidden;
                margin-top: 50px;
            }
        </style>
    </head>
    <body>
        <div class="navbar sticky-top">
            <a style="margin-left: 275px; margin-top: 8px;">Flipkart</a>
            <a><input type="search" name="search" placeholder="search" style="width: 350px; margin-left: 50px; margin-top: 8px;"></a>
            <div class="dropdown">
                <p class="dropbtn" style="margin-left: 75px; margin-top: 8px; cursor: pointer;">More</p>
                <div class="dropdown-content">
                    <a>Notification Preferences</a>
                    <a>Sell On Flipkart</a>
                    <a>24x7 Customer Care</a>
                    <a>Advertise</a>
                    <a>Download App</a>
                </div>
            </div>
            <a style="margin-left: 100px; margin-top: 8px;">Cart</a>
        </div>
        <div class="mi5g">
            <img src="./Screenshot 2022-03-26 144431.png" style="margin-left: 200px;  float: left;">
            <div class="mi5gspecs">
                <h3>Xiaomi 11i 5G (Stealth Black, 128 GB)</h3>
                <ul>
                    <li>6 GB RAM | 128 GB ROM | Expandable Upto 1 TB</li>
                    <li>16.94 CM (6.67 inch) Full HD+ AMOLED Display</li>
                    <li>108 MP Rear Camera | 16 MP Front Camera</li>
                    <li>5160 mAh Battery</li>
                    <li>MediaTek Dimensity 920 Processor</li>
                    <li>1 Year Warranty</li>
                    <li>Price 24,999</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <hr>
        <div class="mi11tpro5g">
            <img src="./Screenshot 2022-03-26 144452.png" style="margin-left: 200px;  float: left;"> 
            <div class="mi11tpro5gspecs">
                <h3>Xiaomi 11T Pro 5G Hyperphone(Celestial Magic, 128 GB)</h3>
                <ul>
                    <li>8 GB RAM | 128 GB ROM</li>
                    <li>16.94 cm (6.67 inch) Display</li>
                    <li>108 MP Rear Camera</li>
                    <li>5000 mAh Battery</li>
                    <li>1 Year Warranty</li>
                    <li>Price 36,850</li>
                </ul>
                <br>
                <br>
                <a href="phpform.php"><button style="background-color: tomato; color: white; border: none; text-decoration: none; padding: 20px; float: right; margin-right: 75px; cursor: pointer;" onclick="performclick">BUY NOW</button></a>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <hr>
    </body>
</html>